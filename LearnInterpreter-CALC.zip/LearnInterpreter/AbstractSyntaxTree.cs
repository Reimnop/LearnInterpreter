﻿namespace LearnInterpreter
{
    public class AbstractSyntaxTree
    {
        public Node RootNode;

        public AbstractSyntaxTree(Node root)
        {
            RootNode = root;
        }
    }
}
