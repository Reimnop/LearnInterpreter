﻿using System;

namespace LearnInterpreter
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            Interpreter interpreter = new Interpreter(new Lexer(Console.ReadLine()));
            Console.WriteLine(interpreter.Evaluate());
        }
    }
}
